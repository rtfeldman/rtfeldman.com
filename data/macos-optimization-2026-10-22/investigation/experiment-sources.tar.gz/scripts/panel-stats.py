import csv,statistics,sys,collections,json
rows=list(csv.DictReader(open(sys.argv[1])))
g=collections.defaultdict(list)
for r in rows:g[r['engine'],r['corpus'],int(r['level'])].append(int(r['ns']))
engines=list(dict.fromkeys(r['engine'] for r in rows if r['engine']!='C'))
result={}
for e in engines:
 cases=[]
 for (x,f,l),values in g.items():
  if x!=e or ('C',f,l) not in g:continue
  c=statistics.median(g['C',f,l]);roc=statistics.median(values)
  cases.append(dict(corpus=f,level=l,gap_pct=100*(roc/c-1),roc_ns=roc,c_ns=c,samples=len(values)))
 cases.sort(key=lambda x:x['gap_pct'],reverse=True)
 if not cases:continue
 result[e]=dict(cases=len(cases),median_gap=statistics.median(c['gap_pct'] for c in cases),worst=cases[0],by_level={str(l):dict(median=statistics.median(c['gap_pct'] for c in cases if c['level']==l),worst=max(c['gap_pct'] for c in cases if c['level']==l)) for l in sorted(set(c['level'] for c in cases))})
print(json.dumps(result,indent=2))
