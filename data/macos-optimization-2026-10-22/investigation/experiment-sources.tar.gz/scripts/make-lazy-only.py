from pathlib import Path
import subprocess
r=Path('/Users/rtfeldman/code/worktrees/roc-deflate/macos-deflate-gap/roc-deflate');s=Path('/private/tmp/roc-gap-2026-10-22')
old=subprocess.check_output(['git','show','dd9fbc6:package/CompressLazy.roc'],cwd=r,text=True)
new=(s/'variants/CompressLazy.split-all.roc').read_text()
head=old[:old.index('\tcompress :')].replace('import HcMatchfinder','import HcMatchfinder\nimport HcGreedyMatchfinder',1)
new=head+new[new.index('\tcompress :'):]
(s/'variants/CompressLazy.lazy-only.roc').write_text(new)
