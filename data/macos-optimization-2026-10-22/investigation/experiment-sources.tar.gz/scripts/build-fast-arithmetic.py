from pathlib import Path
import subprocess,shutil,sys
r=Path('/Users/rtfeldman/code/worktrees/roc-deflate/macos-deflate-gap/roc-deflate');s=Path('/private/tmp/roc-gap-2026-10-22');roc='/private/tmp/roc-deflate-compiler-latest-2026-10-22/install-d99/bin/roc'
p=r/'package/CompressFast.roc';saved=p.read_bytes()
try:
 for name,variant in [('fast-base',None),('fast-arithmetic','arithmetic-only')]:
  if len(sys.argv)>1 and name not in sys.argv[1:]:continue
  p.write_bytes(saved)
  if variant:shutil.copyfile(s/'variants'/f'CompressFast.{variant}.roc',p)
  with (s/f'{name}-unit.log').open('w') as log:subprocess.run([roc,'test','package/main.roc'],cwd=r,stdout=log,stderr=subprocess.STDOUT,check=True)
  with (s/f'{name}-build.log').open('w') as log:subprocess.run(['python3','benchmark/echo-clock/measure.py','build','--roc',roc,'--corpus','/private/tmp/roc-deflate-macos-2026-10-21/corpus','--libdeflate','/private/tmp/roc-deflate-macos-2026-10-21/libdeflate','--out',s/name,'--files','dickens','reymont','mr','nci','xml','--levels','1','2','3','4','5','6','7','8','9','--reps','5'],cwd=r,stdout=log,stderr=subprocess.STDOUT,check=True)
  print('built',name,flush=True)
finally:p.write_bytes(saved)
