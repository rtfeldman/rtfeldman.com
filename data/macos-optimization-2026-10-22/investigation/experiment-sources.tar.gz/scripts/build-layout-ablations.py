from pathlib import Path
import subprocess,shutil,json
r=Path('/Users/rtfeldman/code/worktrees/roc-deflate/macos-deflate-gap/roc-deflate');s=Path('/private/tmp/roc-gap-2026-10-22');roc='/private/tmp/roc-deflate-compiler-latest-2026-10-22/install-d99/bin/roc'
saved={p.name:p.read_bytes() for p in (r/'package').glob('*.roc')}
def git(f):return subprocess.check_output(['git','show','e5b2528:package/'+f],cwd=r)
packed={f:git(f) for f in ['CompressOptimal.roc','BlockOut.roc']}
helper=git('HcGreedyMatchfinder.roc').decode().replace('HcGreedyMatchfinder','HcTables').replace('## Separate regions let the greedy parser address each table directly.','## Separate hash heads and chain links for the greedy and lazy parsers.')
constants='''## Hash-chain table dimensions shared by the search and insertion loops.
HcMatchfinder := [].{
\thash3_order : U64
\thash3_order = 15
\thash4_order : U64
\thash4_order = 16
\thash3_size : U64
\thash3_size = 32768
\thash4_size : U64
\thash4_size = 65536
}
'''
lazy=(s/'variants/CompressLazy.walk-all.roc').read_text().replace('HcGreedyMatchfinder','HcTables')
variants=[('layout-packed',False,True),('tables-packed',True,True),('tables-unpacked',True,False)]
def restore():
 for p in (r/'package').glob('*.roc'):p.unlink()
 for f,b in saved.items():(r/'package'/f).write_bytes(b)
try:
 for name,separate,use_packed in variants:
  restore()
  if use_packed:
   for f,b in packed.items():(r/'package'/f).write_bytes(b)
  if separate:
   (r/'package/HcMatchfinder.roc').write_text(constants)
   (r/'package/HcTables.roc').write_text(helper)
   (r/'package/CompressLazy.roc').write_text(lazy)
  snapshot=s/(name+'-source');snapshot.mkdir(exist_ok=True)
  for p in (r/'package').glob('*.roc'):shutil.copyfile(p,snapshot/p.name)
  with (s/f'{name}-unit.log').open('w') as log:subprocess.run([roc,'test','package/main.roc'],cwd=r,stdout=log,stderr=subprocess.STDOUT,check=True)
  with (s/f'{name}-build.log').open('w') as log:subprocess.run(['python3','benchmark/echo-clock/measure.py','build','--roc',roc,'--corpus','/private/tmp/roc-deflate-macos-2026-10-21/corpus','--libdeflate','/private/tmp/roc-deflate-macos-2026-10-21/libdeflate','--out',s/name,'--files','dickens','reymont','mr','nci','xml','--levels','1','2','3','4','5','6','7','8','9','--reps','5'],cwd=r,stdout=log,stderr=subprocess.STDOUT,check=True)
  if separate:
   p=s/name/'build.json';meta=json.loads(p.read_text());meta['extra_package_sources']={'package/HcTables.roc':helper};p.write_text(json.dumps(meta,indent=2)+'\n')
  print('built',name,flush=True)
finally:restore()
