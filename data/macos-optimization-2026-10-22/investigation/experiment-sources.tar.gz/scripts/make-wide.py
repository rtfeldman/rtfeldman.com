from pathlib import Path
root=Path('/Users/rtfeldman/code/worktrees/roc-deflate/macos-deflate-gap/roc-deflate/package')
v=Path('/private/tmp/roc-gap-2026-10-22/variants')
s=(root/'HcMatchfinder.roc').read_text()
s=s.replace('List(U16)','List(U32)').replace('to_u16_wrap()','to_u32_wrap()')
s=s.replace('Matchfinder.init_nodes(HcMatchfinder.table_size)','List.repeat(0.U32, HcMatchfinder.table_size)')
s=s.replace('Matchfinder.rebase_nodes','HcMatchfinder.rebase_nodes').replace('Matchfinder.window_size','HcMatchfinder.rebase_interval').replace('Matchfinder.node_bias','HcMatchfinder.node_bias')
anchor='\thash3_order : U64'
s=s.replace(anchor,'''\t## A 32-bit position has room to slide the coordinate base once every
\t## 2 GiB, while the actual match window remains 32768 bytes. The bias
\t## reserves zero for an unwritten entry and leaves a full half-range
\t## on either side of the current base.
\tnode_bias : U64
\tnode_bias = 2147483648

\trebase_interval : U64
\trebase_interval = 2147483648

\trebase_nodes : List(U32) -> List(U32)
\trebase_nodes = |table| List.map(table, |v| v.minus_saturated(2147483648))

\tnode_index : U64, U32 -> U64
\tnode_index = |base, node| base.plus_wrap(node.to_u64()).minus_wrap(HcMatchfinder.node_bias)

'''+anchor)
(v/'HcMatchfinder.wide.roc').write_text(s)
s=(root/'CompressLazy.roc').read_text()
s=s.replace('Matchfinder.rebase_nodes','HcMatchfinder.rebase_nodes').replace('Matchfinder.node_bias','HcMatchfinder.node_bias').replace('Matchfinder.node_index','HcMatchfinder.node_index')
s=s.replace('$in_next.minus_wrap($base) == Matchfinder.window_size','$in_next.minus_wrap($base) == HcMatchfinder.rebase_interval')
s=s.replace('$base.plus_wrap(Matchfinder.window_size)','$base.plus_wrap(HcMatchfinder.rebase_interval)')
s=s.replace('skip_end.minus_wrap($base) > Matchfinder.window_size','skip_end.minus_wrap($base) > HcMatchfinder.rebase_interval')
# The direct repeated-byte fill needs one contiguous chain-ring segment.
needle='or skip_end.minus_wrap($base) > HcMatchfinder.rebase_interval'
where=s.index(needle)
s=s[:where]+s[where:].replace(needle,needle+'\n\t\t\t\t\t\tor $in_next.bitwise_and(32767).plus_wrap($found.length) > Matchfinder.window_size',1)
# Searches compare nodes against the last excluded window position.
lines=s.splitlines();out=[]
for line in lines:
 out.append(line)
 if line.lstrip().startswith('cur_pos = $in_next.minus_wrap($base)'):
  indent=line[:len(line)-len(line.lstrip())]
  out.append(indent+'oldest_node = cur_pos.plus_wrap(HcMatchfinder.node_bias - Matchfinder.window_size)')
s='\n'.join(out)+'\n'
s=s.replace('<= cur_pos','<= oldest_node')
s=s.replace('(cur_pos.plus_wrap(HcMatchfinder.node_bias)).to_u16_wrap()','(cur_pos.plus_wrap(HcMatchfinder.node_bias)).to_u32_wrap()')
s=s.replace('$skip_node.to_u16_wrap()','$skip_node.to_u32_wrap()').replace('$skip_node.minus_wrap(1).to_u16_wrap()','$skip_node.minus_wrap(1).to_u32_wrap()')
s=s.replace('repeat_limit = repeat_end.minus_wrap($base)','repeat_limit = repeat_end.minus_wrap($skip_at).plus_wrap($skip_node.bitwise_and(32767))\n\t\t\t\t\t\t\trepeat_bias = $skip_node.minus_wrap($skip_node.bitwise_and(32767)).minus_wrap(1)')
s=s.replace('$repeat_slot.plus_wrap(32767).to_u16_wrap()','$repeat_slot.plus_wrap(repeat_bias).to_u32_wrap()')
s=s.replace('$skip_node = repeat_limit.plus_wrap(HcMatchfinder.node_bias)','$skip_node = repeat_end.minus_wrap($base).plus_wrap(HcMatchfinder.node_bias)')
(v/'CompressLazy.wide.roc').write_text(s)
print('Prepared wide hash-chain variant without changing the live package.')
