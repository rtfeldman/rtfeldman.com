from pathlib import Path
root=Path('/Users/rtfeldman/code/worktrees/roc-deflate/macos-deflate-gap/roc-deflate/package')
v=Path('/private/tmp/roc-gap-2026-10-22/variants')
s=(root/'HtMatchfinder.roc').read_text()
s=s.replace('List(U16)','List(U32)').replace('to_u16_wrap()','to_u32_wrap()')
s=s.replace('Matchfinder.rebase_nodes','HtMatchfinder.rebase_nodes').replace('Matchfinder.window_size','HtMatchfinder.rebase_interval').replace('Matchfinder.node_bias','HtMatchfinder.node_bias').replace('Matchfinder.node_index','HtMatchfinder.node_index')
s=s.replace('\thash_order : U64','''\tnode_bias : U64
\tnode_bias = 2147483648

\trebase_interval : U64
\trebase_interval = 2147483648

\trebase_nodes : List(U32) -> List(U32)
\trebase_nodes = |table| List.map(table, |v| v.minus_saturated(2147483648))

\tnode_index : U64, U32 -> U64
\tnode_index = |base, node| base.plus_wrap(node.to_u64()).minus_wrap(HtMatchfinder.node_bias)

\thash_order : U64''')
s=s.replace('cur_pos = in_next.minus_wrap(in_base)','cur_pos = in_next.minus_wrap(in_base)\n\t\toldest_node = cur_pos.plus_wrap(HtMatchfinder.node_bias - Matchfinder.window_size)')
s=s.replace('<= cur_pos','<= oldest_node')
(v/'HtMatchfinder.wide.roc').write_text(s)
s=(root/'CompressFast.roc').read_text()
s=s.replace('Matchfinder.init_nodes(HtMatchfinder.table_size)','List.repeat(0.U32, HtMatchfinder.table_size)')
s=s.replace('Matchfinder.rebase_nodes','HtMatchfinder.rebase_nodes').replace('Matchfinder.window_size','HtMatchfinder.rebase_interval').replace('Matchfinder.node_bias','HtMatchfinder.node_bias').replace('Matchfinder.node_index','HtMatchfinder.node_index')
s=s.replace('0.U16','0.U32')
# Only match-position casts become wider; sequence offsets remain U16.
s=s.replace('to_u16_wrap()','to_u32_wrap()')
s=s.replace('offset: $found_offset.to_u32_wrap()','offset: $found_offset.to_u16_wrap()').replace('offset_slot: offset_slot.to_u32_wrap()','offset_slot: offset_slot.to_u16_wrap()').replace('offset: 0.U32','offset: 0.U16').replace('offset_slot: 0.U32','offset_slot: 0.U16')
lines=[]
for line in s.splitlines():
 lines.append(line)
 if line.lstrip()=='cur_pos = $in_next.minus_wrap($base)':
  indent=line[:len(line)-len(line.lstrip())]
  lines.append(indent+'oldest_node = cur_pos.plus_wrap(HtMatchfinder.node_bias - Matchfinder.window_size)')
s='\n'.join(lines)+'\n'
s=s.replace('> cur_pos','> oldest_node').replace('<= cur_pos','<= oldest_node')
(v/'CompressFast.wide.roc').write_text(s)
print('Prepared wide hash-table candidate.')
