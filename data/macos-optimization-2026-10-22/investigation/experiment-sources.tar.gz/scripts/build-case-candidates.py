from pathlib import Path
import subprocess,shutil,json
root=Path('/Users/rtfeldman/code/worktrees/roc-deflate/macos-deflate-gap/roc-deflate')
s=Path('/private/tmp/roc-gap-2026-10-22')
latest='/private/tmp/roc-deflate-compiler-latest-2026-10-22/install-d99/bin/roc'
previous='/private/tmp/roc-deflate-compiler-latest-2026-10-22/install/bin/roc'
files=['CompressLazy','CompressFast']; saved={f:(root/'package'/f'{f}.roc').read_bytes() for f in files}
extra=root/'package/HcGreedyMatchfinder.roc';assert not extra.exists()
split={'CompressLazy':'split-greedy','HcGreedyMatchfinder':'split-greedy'}
pair={'CompressFast':'bucket-pair'}
variants=[('case-29bd',previous,{}),('case-d99',latest,{}),('case-split',latest,split),('case-pair',latest,pair),('case-both',latest,split|pair)]
try:
 for name,roc,changed in variants:
  for f,b in saved.items():(root/'package'/f'{f}.roc').write_bytes(b)
  extra.unlink(missing_ok=True)
  for f,variant in changed.items():shutil.copyfile(s/'variants'/f'{f}.{variant}.roc',root/'package'/f'{f}.roc')
  with (s/f'{name}-unit.log').open('w') as log:subprocess.run([roc,'test','package/main.roc'],cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
  with (s/f'{name}-build.log').open('w') as log:subprocess.run(['python3','benchmark/echo-clock/measure.py','build','--roc',roc,'--corpus','/private/tmp/roc-deflate-macos-2026-10-21/corpus','--libdeflate','/private/tmp/roc-deflate-macos-2026-10-21/libdeflate','--out',s/name,'--files','dickens','reymont','mr','nci','xml','--levels','1','2','3','4','8','9','--reps','3'],cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
  if extra.exists():
   p=s/name/'build.json';meta=json.loads(p.read_text());meta['extra_package_sources']={'package/HcGreedyMatchfinder.roc':extra.read_text()};p.write_text(json.dumps(meta,indent=2)+'\n')
  print('built',name,flush=True)
finally:
 for f,b in saved.items():(root/'package'/f'{f}.roc').write_bytes(b)
 extra.unlink(missing_ok=True)
