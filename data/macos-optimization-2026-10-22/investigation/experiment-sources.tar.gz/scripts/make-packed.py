from pathlib import Path
p=Path('/private/tmp/roc-gap-2026-10-22/variants')
s=(p/'HtMatchfinder.base.roc').read_text().replace('List(U16)','List(U32)').replace('table_size = 65536','table_size = 32768').replace('Matchfinder.rebase_nodes($tab)','HtMatchfinder.rebase_nodes($tab)').replace('.bitwise_and(0x7FFF).times_wrap(2)', '.bitwise_and(0x7FFF)')
a=s.index('\t\tcur_node0 = List.get($tab, slot0) ?? 0')
b=s.index('\n\t\tvar $best_len',a)
s=s[:a]+'''\t\tbucket = List.get($tab, slot0) ?? 0
\t\tcur_node0 = bucket.to_u16_wrap()
\t\ttab1 = match List.set($tab, slot0, bucket.shl_wrap(16).bitwise_or(cur_pos.plus_wrap(Matchfinder.node_bias).to_u16_wrap().to_u32())) {
\t\t\tOk(next) => next
\t\t\tErr(_) => crash "HtMatchfinder.longest_match: tab index out of bounds"
\t\t}
'''+s[b:]
s=s.replace('slot0.plus_wrap(1) >= List.len($tab)','slot0 >= List.len($tab)')
a=s.index('\t\t\t# Push the displaced entry into the second slot.')
b=s.index('\n\t\t\tif (U32.from_le_bytes',a)
s=s[:a]+'''\t\t\tcur_node1 = bucket.shr_zf_wrap(16).to_u16_wrap()
'''+s[b:]
s=s.replace('hash_tab: $tab2','hash_tab: tab1')
a=s.index('\t\t\t\ttab1 = match List.set($tab, slot0.plus_wrap(1), first)')
b=s.index('\n\n\t\t\t\t$in_next',a)
s=s[:a]+'''\t\t\t\t$tab = match List.set($tab, slot0, first.shl_wrap(16).bitwise_or($node.to_u16_wrap().to_u32())) {
\t\t\t\t\tOk(next) => next
\t\t\t\t\tErr(_) => crash "HtMatchfinder.skip_bytes: bucket index out of bounds"
\t\t\t\t}
'''+s[b:]
pos=s.index('\n\t## Find the longest match')
s=s[:pos]+'''
\t## Saturating-subtract 32768 from both packed 16-bit lanes. Each high
\t## bit creates a mask for its lane; expired positions become zero.
\trebase_nodes : List(U32) -> List(U32)
\trebase_nodes = |table|
\t\tList.map(table, |bucket| {
\t\t\thigh = bucket.bitwise_and(0x80008000)
\t\t\tmask = high.minus_wrap(high.shr_zf_wrap(15))
\t\t\tbucket.bitwise_and(mask)
\t\t})
'''+s[pos:]
(p/'HtMatchfinder.packed.roc').write_text(s)
s=(p/'CompressFast.base.roc').read_text().replace('Matchfinder.init_nodes(HtMatchfinder.table_size)','List.repeat(0.U32, HtMatchfinder.table_size)').replace('Matchfinder.rebase_nodes($tab)','HtMatchfinder.rebase_nodes($tab)').replace('.bitwise_and(0x7FFF).times_wrap(2)', '.bitwise_and(0x7FFF)').replace('.bitwise_and(32767).times_wrap(2)', '.bitwise_and(32767)').replace('List.prefetched($tab, $nh.times_wrap(2))','List.prefetched($tab, $nh)')
a=s.index('\t\t\t\t\t\tcur_node0 = List.get($tab, slot0) ?? 0')
b=s.index('\n\t\t\t\t\t\t\tif (U32.from_le_bytes',a)
s=s[:a]+'''\t\t\t\t\t\tbucket = List.get($tab, slot0) ?? 0
\t\t\t\t\t\tcur_node0 = bucket.to_u16_wrap()
\t\t\t\t\t\t$tab = match List.set($tab, slot0, bucket.shl_wrap(16).bitwise_or(cur_pos.plus_wrap(Matchfinder.node_bias).to_u16_wrap().to_u32())) {
\t\t\t\t\t\t\tOk(next) => next
\t\t\t\t\t\t\tErr(_) => crash "CompressFast.compress: bucket index out of bounds"
\t\t\t\t\t\t}
\t\t\t\t\t\tif cur_node0.to_u64() > cur_pos {
\t\t\t\t\t\t\tcur_node1 = bucket.shr_zf_wrap(16).to_u16_wrap()
'''+s[b:]
a=s.index('\t\t\t\t\t\t\t\t$tab = match List.set($tab, slot0, latest.to_u16_wrap())')
b=s.index('\n\t\t\t\t\t\t\t\t$skip_at = uniform_end',a)
s=s[:a]+'''\t\t\t\t\t\t\t\tpacked = latest.to_u16_wrap().to_u32().bitwise_or(latest.minus_wrap(1).to_u16_wrap().to_u32().shl_wrap(16))
\t\t\t\t\t\t\t\t$tab = match List.set($tab, slot0, packed) {
\t\t\t\t\t\t\t\t\tOk(next) => next
\t\t\t\t\t\t\t\t\tErr(_) => crash "CompressFast.compress: uniform bucket index out of bounds"
\t\t\t\t\t\t\t\t}
'''+s[b:]
a=s.index('\t\t\t\t\t\t\t\t$tab = match List.set($tab, slot0.plus_wrap(1), first)')
b=s.index('\n\t\t\t\t\t\t\t\t$skip_at = $skip_at.plus_wrap(1)',a)
s=s[:a]+'''\t\t\t\t\t\t\t\t$tab = match List.set($tab, slot0, first.shl_wrap(16).bitwise_or($skip_node.to_u16_wrap().to_u32())) {
\t\t\t\t\t\t\t\t\tOk(next) => next
\t\t\t\t\t\t\t\t\tErr(_) => crash "CompressFast.compress: bucket index out of bounds"
\t\t\t\t\t\t\t\t}
'''+s[b:]
(p/'CompressFast.packed.roc').write_text(s)
