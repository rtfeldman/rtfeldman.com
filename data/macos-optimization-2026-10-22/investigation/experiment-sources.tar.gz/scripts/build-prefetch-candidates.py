from pathlib import Path
import subprocess,json
root=Path('/Users/rtfeldman/code/worktrees/roc-deflate/macos-deflate-gap/roc-deflate')
s=Path('/private/tmp/roc-gap-2026-10-22')
roc='/private/tmp/roc-deflate-compiler-latest-2026-10-22/install-d99/bin/roc'
files=['CompressLazy','CompressFast'];saved={f:(root/'package'/f'{f}.roc').read_bytes() for f in files}
try:
 for name,changed in [('prefetch-base',[]),('no-prefetch',['CompressLazy','CompressFast'])]:
  for f,b in saved.items():
   data=b.decode()
   if f in changed:
    data=''.join(line for line in data.splitlines(keepends=True) if ' = List.prefetched(' not in line)
    (s/'variants'/f'{f}.no-prefetch.roc').write_text(data)
   (root/'package'/f'{f}.roc').write_text(data)
  with (s/f'{name}-unit.log').open('w') as log:subprocess.run([roc,'test','package/main.roc'],cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
  with (s/f'{name}-build.log').open('w') as log:subprocess.run(['python3','benchmark/echo-clock/measure.py','build','--roc',roc,'--corpus','/private/tmp/roc-deflate-macos-2026-10-21/corpus','--libdeflate','/private/tmp/roc-deflate-macos-2026-10-21/libdeflate','--out',s/name,'--files','dickens','reymont','mr','nci','xml','--levels','1','2','3','4','8','9','--reps','5'],cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
  print('built',name,flush=True)
finally:
 for f,b in saved.items():(root/'package'/f'{f}.roc').write_bytes(b)
