from pathlib import Path
import re,subprocess
root=Path('/Users/rtfeldman/code/worktrees/roc-deflate/macos-deflate-gap/roc-deflate');v=Path('/private/tmp/roc-gap-2026-10-22/variants')
s=subprocess.check_output(['git','show','0660245:package/CompressLazy.roc'],cwd=root,text=True)
b=s.index('\tcompress :');head,tail=s[:b],s[b:];lines=[]
for line in tail.splitlines():
 indent=line[:len(line)-len(line.lstrip())]
 if 'var $mf = HcMatchfinder.init_tables({})' in line:
  lines += [indent+'var $mf3 = List.repeat(0.U16, HcMatchfinder.hash3_size)',indent+'var $mf4 = List.repeat(0.U16, HcMatchfinder.hash4_size)',indent+'var $mfnext = List.repeat(0.U16, Matchfinder.window_size)'];continue
 if '$mf = Matchfinder.rebase_nodes($mf)' in line:
  lines += [indent+f'${name} = Matchfinder.rebase_nodes(${name})' for name in ['mf3','mf4','mfnext']];continue
 if '$mf = skipped.tab' in line:
  lines += [indent+f'${name} = skipped.{field}' for name,field in [('mf3','head3'),('mf4','head4'),('mfnext','chain')]];continue
 if 'HcMatchfinder.skip_bytes($mf,' in line:
  line=line.replace('HcMatchfinder.skip_bytes($mf,','HcGreedyMatchfinder.skip_bytes($mf3, $mf4, $mfnext,').replace(', HcMatchfinder.default_layout)',')')
 line=line.replace('List.len($mf) < HcMatchfinder.table_size','(List.len($mf3) < HcMatchfinder.hash3_size or List.len($mf4) < HcMatchfinder.hash4_size or List.len($mfnext) < Matchfinder.window_size)')
 if '$mf' in line and any(x in line for x in ['List.get(','List.set(','List.prefetched(']):
  if 'hash3_base' in line or 'slot3' in line: target='$mf3'
  elif 'hash4_base' in line or 'slot4' in line: target='$mf4'
  elif 'next_base' in line:target='$mfnext'
  else:raise ValueError(line)
  line=re.sub(r'\$mf\b',lambda _:target,line)
 pattern=re.compile(r'HcMatchfinder\.(?:hash3_base|hash4_base|next_base)\.plus_wrap\(')
 while m:=pattern.search(line):
  start=m.end();depth=1;end=start
  while depth:
   if line[end]=='(':depth+=1
   elif line[end]==')':depth-=1
   end+=1
  line=line[:m.start()]+line[start:end-1]+line[end:]
 lines.append(line)
tail='\n'.join(lines)+'\n';assert not re.search(r'\$mf\b',tail)
(v/'CompressLazy.split-all.roc').write_text(head+tail)
