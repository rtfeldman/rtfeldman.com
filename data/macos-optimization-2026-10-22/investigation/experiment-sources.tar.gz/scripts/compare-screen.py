import csv,json,pathlib,statistics,subprocess,sys,os,time
root=pathlib.Path('/private/tmp/roc-gap-2026-10-22')
names=sys.argv[1:]
metas={n:json.loads((root/n/'build.json').read_text()) for n in names}
base=metas[names[0]]
assert all(m['files']==base['files'] and m['levels']==base['levels'] and m['reps']==base['reps'] for m in metas.values())
rounds=int(os.environ.get('ROUNDS','3'))
rows=[]
out=root/('-'.join(names)+'-comparison.csv')
env={k:v for k,v in os.environ.items() if k not in ('DYLD_INSERT_LIBRARIES','LD_PRELOAD')}
with out.open('w') as f:
    w=csv.writer(f);w.writerow(['engine','corpus','level','round','rep','ns','compressed_bytes'])
    for r in range(1,rounds+1):
        for file in base['files']:
            engines=['C',*names] if r%2 else [*reversed(names),'C']
            for e in engines:
                d=root/(names[0] if e=='C' else e)/file
                cmds=[[d/'cbench','embedded',str(l),str(base['reps'])] for l in base['levels']] if e=='C' else [[d/'rocbench']]
                for cmd in cmds:
                    text=subprocess.check_output(cmd,text=True,env=env)
                    samples=[l.split('\t') for l in text.splitlines() if l.startswith('rep\t')]
                    assert len(samples)==base['reps']*(1 if e=='C' else len(base['levels']))
                    for _,l,rep,ns,size in samples:
                        row=[e,file,int(l),r,int(rep)+1,int(ns),int(size)];rows.append(row);w.writerow(row)
                    f.flush()
            print(r,file,time.strftime('%H:%M:%S'),flush=True)
g={}
for e,c,l,r,p,ns,size in rows:g.setdefault((c,l,e),[]).append(ns)
result=[]
for c,l in sorted({(r[1],r[2]) for r in rows}):
    med={e:statistics.median(g[c,l,e]) for e in ['C',*names]}
    gaps={e:100*(med[e]/med['C']-1) for e in names}
    result.append([c,l,*[gaps[e] for e in names]])
    print(c,l,' | '.join(f'{e} {gaps[e]:+.2f}%' for e in names))
with out.with_suffix('.summary.csv').open('w') as f:
    w=csv.writer(f);w.writerow(['corpus','level',*names]);w.writerows(result)
print(out)
