from pathlib import Path
import subprocess
s=Path('/private/tmp/roc-gap-2026-10-22');r=Path('/Users/rtfeldman/code/worktrees/roc-deflate/macos-deflate-gap/roc-deflate')
t=subprocess.check_output(['git','show','0660245:package/CompressFast.roc'],cwd=r,text=True)
helper='''\t## A distance slot is its exponent and next significand bit. OR with
\t## 3 clamps the exponent so distances 1 through 4 use the same formula.
\tslot_from_distance : U64 -> U64
\tslot_from_distance = |offset| {
\t\td = offset.minus_wrap(1)
\t\tshift = 62.U64.minus_wrap(d.bitwise_or(3).count_leading_zero_bits().to_u64())
\t\td.shr_zf_wrap(shift.to_u8_wrap()).plus_wrap(shift.shl_wrap(1))
\t}

'''
assert t.count('DeflateTables.offset_slot($found_offset)')==1
t=t.replace('\tcompress :',helper+'\tcompress :',1).replace('DeflateTables.offset_slot($found_offset)','CompressFast.slot_from_distance($found_offset)')
t+='''
# Check every legal DEFLATE distance against the independent lookup table.
expect {
\tvar $distance = 1.U64
\tvar $same = True
\twhile $distance <= Matchfinder.window_size and $same {
\t\t$same = CompressFast.slot_from_distance($distance) == DeflateTables.offset_slot($distance)
\t\t$distance = $distance + 1
\t}
\t$same
}
'''
(s/'variants/CompressFast.arithmetic-only.roc').write_text(t)
