from pathlib import Path
import subprocess,shutil
root=Path('/Users/rtfeldman/code/worktrees/roc-deflate/macos-deflate-gap/roc-deflate');s=Path('/private/tmp/roc-gap-2026-10-22')
roc='/private/tmp/roc-deflate-compiler-latest-2026-10-22/install-d99/bin/roc';p=root/'package/CompressLazy.roc';saved=p.read_bytes()
try:
 shutil.copyfile(s/'variants/CompressLazy.lazy-only.roc',p)
 with (s/'lazy-only-unit.log').open('w') as log:subprocess.run([roc,'test','package/main.roc'],cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
 with (s/'lazy-only-build.log').open('w') as log:subprocess.run(['python3','benchmark/echo-clock/measure.py','build','--roc',roc,'--corpus','/private/tmp/roc-deflate-macos-2026-10-21/corpus','--libdeflate','/private/tmp/roc-deflate-macos-2026-10-21/libdeflate','--out',s/'lazy-only','--files','dickens','reymont','mr','nci','xml','--levels','1','2','3','4','5','6','7','8','9','--reps','5'],cwd=root,stdout=log,stderr=subprocess.STDOUT,check=True)
 print('built lazy-only',flush=True)
finally:p.write_bytes(saved)
