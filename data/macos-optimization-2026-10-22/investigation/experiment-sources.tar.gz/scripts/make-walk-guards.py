from pathlib import Path
import re,subprocess
s=Path('/private/tmp/roc-gap-2026-10-22');r=Path('/Users/rtfeldman/code/worktrees/roc-deflate/macos-deflate-gap/roc-deflate')
new=subprocess.check_output(['git','show','04cb55f:package/CompressLazy.roc'],cwd=r,text=True)
blocks={}
for suffix in ['', '_s','_n','_m']:
 pat=re.compile(r'(?m)^(\t*)while \$done'+suffix+r' == 0 \{\n')
 m=pat.search(new);assert m
 start=m.end();end=new.index(m.group(1)+'\tvar $cand_at'+suffix,start)
 blocks[suffix]=new[start:end]
base=subprocess.check_output(['git','show','0660245:package/CompressLazy.roc'],cwd=r,text=True)
for name,src in [('base',base),('all',(s/'variants/CompressLazy.split-all.roc').read_text()),('only',(s/'variants/CompressLazy.lazy-only.roc').read_text())]:
 for suffix,block in blocks.items():
  pat=re.compile(r'(?m)^(\t*)while \$done'+suffix+r' == 0 \{\n')
  assert len(pat.findall(src))==1
  src=pat.sub(lambda m:m.group(0)+block,src)
 (s/'variants'/f'CompressLazy.walk-{name}.roc').write_text(src)
