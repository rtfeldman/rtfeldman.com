from pathlib import Path
import re
root=Path('/Users/rtfeldman/code/worktrees/roc-deflate/macos-deflate-gap/roc-deflate/package')
v=Path('/private/tmp/roc-gap-2026-10-22/variants')
s=(root/'CompressLazy.roc').read_text()
pattern=re.compile(r'(?m)^(\t*)while \$skip_at < skip_limit \{\n')
for m in reversed(list(pattern.finditer(s))):
 i=m[1]; end=s.index('\n'+i+'}',m.end()); body=s[m.end():end]
 body=body.replace('skip_node = $skip_node.to_u16_wrap()','skip_node = $chain_at.plus_wrap(Matchfinder.node_bias).to_u16_wrap()')
 body=body.replace('$skip_node.bitwise_and(32767)','$chain_at')
 body=body.replace('$skip_at = $skip_at.plus_wrap(1)','$chain_at = $chain_at.plus_wrap(1)')
 body=body.replace(i+'\t$skip_node = $skip_node.plus_wrap(1)\n','')
 body=body.replace('U32.from_le_bytes(input, $skip_at)','U32.from_le_bytes(input, $base.plus_wrap($chain_at))')
 pre=i+'chain_limit = skip_limit.minus_wrap($base)\n'
 pre+=i+'if $base > $skip_at or $skip_at > skip_limit or chain_limit > Matchfinder.window_size or $base + chain_limit + 4 > List.len(input) {\n'
 pre+=i+'\tcrash "skip chain outside window"\n'+i+'} else {}\n'
 pre+=i+'var $chain_at = $skip_at.minus_wrap($base)\n'+i+'while $chain_at < chain_limit {\n'
 s=s[:m.start()]+pre+body+s[end:]
line = '\t'*9 + 'var $skip_node = $skip_at.minus_wrap($base).plus_wrap(Matchfinder.node_bias)\n'
assert s.count(line) == 1
s=s.replace(line,'')
(v/'CompressLazy.linear.roc').write_text(s)
