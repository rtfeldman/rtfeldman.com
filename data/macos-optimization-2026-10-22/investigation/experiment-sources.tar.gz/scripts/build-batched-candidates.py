from pathlib import Path
import subprocess,shutil
root=Path('/Users/rtfeldman/code/worktrees/roc-deflate/macos-deflate-gap/roc-deflate')
s=Path('/private/tmp/roc-gap-2026-10-22')
roc='/private/tmp/roc-deflate-compiler-latest-2026-10-22/install-d99/bin/roc'
files=['HcMatchfinder','CompressLazy','HtMatchfinder','CompressFast']
backup={f:(root/'package'/f'{f}.roc').read_bytes() for f in files}
try:
 for name,variant,changed in [('guard-d99',None,[]),('smallbias','wide-smallbias',files),('batch2','batch-2',['CompressLazy','CompressFast']),('batch4','batch-4',['CompressLazy','CompressFast']),('vector4','batch-vector',['CompressLazy','CompressFast']),('linear','linear',['CompressLazy']),('earlyload','early-load',['CompressLazy','CompressFast']),('vector2','vector2',['CompressLazy'])]:
  for f,b in backup.items():(root/'package'/f'{f}.roc').write_bytes(b)
  for f in changed:shutil.copyfile(s/'variants'/f'{f}.{variant}.roc',root/'package'/f'{f}.roc')
  with (s/f'{name}-unit.log').open('w') as log:
   result=subprocess.run([roc,'test','package/main.roc'],cwd=root,stdout=log,stderr=subprocess.STDOUT)
  if result.returncode:print('unit/typecheck failed',name,flush=True);continue
  with (s/f'{name}-build.log').open('w') as log:
   result=subprocess.run(['python3','benchmark/echo-clock/measure.py','build','--roc',roc,'--corpus','/private/tmp/roc-deflate-macos-2026-10-21/corpus','--libdeflate','/private/tmp/roc-deflate-macos-2026-10-21/libdeflate','--out',s/name,'--files','dickens','reymont','mr','nci','xml','--levels','1','2','3','4','8','9','--reps','5'],cwd=root,stdout=log,stderr=subprocess.STDOUT)
  print('built' if result.returncode==0 else 'build failed',name,flush=True)
finally:
 for f,b in backup.items():(root/'package'/f'{f}.roc').write_bytes(b)
