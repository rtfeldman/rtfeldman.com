from pathlib import Path
import subprocess,shutil
r=Path('/Users/rtfeldman/code/worktrees/roc-deflate/macos-deflate-gap/roc-deflate');s=Path('/private/tmp/roc-gap-2026-10-22');roc='/private/tmp/roc-deflate-compiler-latest-2026-10-22/install-d99/bin/roc'
files=['CompressLazy','CompressOptimal','BlockOut'];saved={f:(r/'package'/f'{f}.roc').read_bytes() for f in files}
try:
 (r/'package/CompressLazy.roc').write_bytes(subprocess.check_output(['git','show','0660245:package/CompressLazy.roc'],cwd=r))
 for f in ['CompressOptimal','BlockOut']:shutil.copyfile(s/'variants'/f'{f}.indexed.roc',r/'package'/f'{f}.roc')
 with (s/'bt-indexed-fixed-unit.log').open('w') as log:subprocess.run([roc,'test','package/main.roc'],cwd=r,stdout=log,stderr=subprocess.STDOUT,check=True)
 with (s/'bt-indexed-fixed-build.log').open('w') as log:subprocess.run(['python3','benchmark/echo-clock/measure.py','build','--roc',roc,'--corpus','/private/tmp/roc-deflate-macos-2026-10-21/corpus','--libdeflate','/private/tmp/roc-deflate-macos-2026-10-21/libdeflate','--out',s/'bt-indexed-fixed','--files','mr','x-ray','nci','reymont','--levels','10','11','12','--reps','3'],cwd=r,stdout=log,stderr=subprocess.STDOUT,check=True)
 print('built bt-indexed-fixed',flush=True)
finally:
 for f,b in saved.items():(r/'package'/f'{f}.roc').write_bytes(b)
