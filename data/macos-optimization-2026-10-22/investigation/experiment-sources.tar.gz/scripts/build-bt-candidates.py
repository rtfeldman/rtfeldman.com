from pathlib import Path
import subprocess,shutil
root=Path('/Users/rtfeldman/code/worktrees/roc-deflate/macos-deflate-gap/roc-deflate')
s=Path('/private/tmp/roc-gap-2026-10-22')
roc='/private/tmp/roc-deflate-compiler-latest-2026-10-22/install-d99/bin/roc'
files=['BtMatchfinder','CompressOptimal','BlockOut'];saved={f:(root/'package'/f'{f}.roc').read_bytes() for f in files}
variants=[('bt-base',{}),('bt-direct',{'BtMatchfinder':'direct'}),('bt-unpacked',{'CompressOptimal':'unpacked','BlockOut':'unpacked'}),('bt-both',{'BtMatchfinder':'direct','CompressOptimal':'unpacked','BlockOut':'unpacked'}),('bt-indexed',{'CompressOptimal':'indexed','BlockOut':'indexed'})]
try:
 for name,changed in variants:
  for f,b in saved.items():(root/'package'/f'{f}.roc').write_bytes(b)
  for f,variant in changed.items():shutil.copyfile(s/'variants'/f'{f}.{variant}.roc',root/'package'/f'{f}.roc')
  with (s/f'{name}-unit.log').open('w') as log:r=subprocess.run([roc,'test','package/main.roc'],cwd=root,stdout=log,stderr=subprocess.STDOUT)
  if r.returncode:print('unit/typecheck failed',name,flush=True);continue
  with (s/f'{name}-build.log').open('w') as log:r=subprocess.run(['python3','benchmark/echo-clock/measure.py','build','--roc',roc,'--corpus','/private/tmp/roc-deflate-macos-2026-10-21/corpus','--libdeflate','/private/tmp/roc-deflate-macos-2026-10-21/libdeflate','--out',s/name,'--files','mr','x-ray','nci','reymont','--levels','10','11','12','--reps','3'],cwd=root,stdout=log,stderr=subprocess.STDOUT)
  print('built' if r.returncode==0 else 'build failed',name,flush=True)
finally:
 for f,b in saved.items():(root/'package'/f'{f}.roc').write_bytes(b)
