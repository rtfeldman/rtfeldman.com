from pathlib import Path
import re
root=Path('/Users/rtfeldman/code/worktrees/roc-deflate/macos-deflate-gap/roc-deflate/package')
v=Path('/private/tmp/roc-gap-2026-10-22/variants')

def transform(src, mode):
 pattern=re.compile(r'(?m)^(\t*)while \$skip_at < skip_limit \{\n')
 matches=list(pattern.finditer(src))
 for m in reversed(matches):
  indent=m[1]; start=m.end(); end=src.index('\n'+indent+'}',start)
  body=src[start:end]+'\n'
  # Only same-indentation close brace closes this loop.
  def renamed(text,lane):
   for name in ['skip_node','prev_head','skip_hashseq','slot0','first']:
    text=re.sub(r'(?<![$\w])'+name+r'\b',name+'_'+str(lane),text)
   return text
  n=4 if mode=='vector' else int(mode)
  if mode!='vector':
   new=indent+f'batch_limit = skip_limit.minus_saturated({n-1})\n'+indent+'while $skip_at < batch_limit {\n'
   new+=''.join(renamed(body,i) for i in range(n))+indent+'}\n'
  else:
   hc='$nh3 =' in body
   body2='\n'.join(line for line in body.splitlines() if not any(x in line for x in ['skip_hashseq =','$nh3 =','$nh4 =','$nh =']))+'\n'
   inner=indent+'\t\t'
   new=indent+'vector_limit = skip_limit.minus_saturated(3).min(List.len(input).minus_saturated(15))\n'
   new+=indent+'if $skip_at < vector_limit {\n'+indent+'\twhile $skip_at < vector_limit {\n'
   new+=inner+'bytes = U8x16.load(input, $skip_at) ?? crash "skip vector outside input"\n'
   new+=inner+'lanes = bytes.table_lookup(U8x16.from_list([0,1,2,3,1,2,3,4,2,3,4,5,3,4,5,6]) ?? crash "shuffle length").to_u32x4_bits()\n'
   if hc:new+=inner+'hashes3 = lanes.bitwise_and(U32x4.splat(0xFFFFFF)).times_wrap(U32x4.splat(0x1E35A7BD)).shr_zf_wrap(17)\n'
   new+=inner+'hashes4 = lanes.times_wrap(U32x4.splat(0x1E35A7BD)).shr_zf_wrap('+('16' if hc else '17')+')\n'
   for i in range(4):
    if hc:
     new+=inner+f'$nh3 = hashes3.get_lane({i}).bitwise_and(32767).to_u64()\n'+inner+f'$nh4 = hashes4.get_lane({i}).bitwise_and(65535).to_u64()\n'
    else:new+=inner+f'$nh = hashes4.get_lane({i}).bitwise_and(32767).to_u64()\n'
    new+='\n'.join('\t'+line for line in renamed(body2,i).splitlines())+'\n'
   new+=indent+'\t}\n'
   if hc:
    new+=indent+'\tfinal_seq = U32.from_le_bytes(input, $skip_at) ?? 0\n'
    new+=indent+'\t$nh3 = Matchfinder.lz_hash(final_seq.bitwise_and(0xFFFFFF), HcMatchfinder.hash3_order)\n'
    new+=indent+'\t$nh4 = Matchfinder.lz_hash(final_seq, HcMatchfinder.hash4_order)\n'
   else:new+=indent+'\t$nh = Matchfinder.lz_hash(U32.from_le_bytes(input, $skip_at) ?? 0, HtMatchfinder.hash_order)\n'
   new+=indent+'} else {}\n'
  src=src[:m.start()]+new+src[m.start():]
 return src
for mode in ['2','4','vector']:
 for stem in ['CompressLazy','CompressFast']:
  (v/f'{stem}.batch-{mode}.roc').write_text(transform((root/f'{stem}.roc').read_text(),mode))
print('Prepared scalar pair, scalar four, and vector four insertion candidates.')
