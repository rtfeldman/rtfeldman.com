from pathlib import Path
import re
root=Path('/Users/rtfeldman/code/worktrees/roc-deflate/macos-deflate-gap/roc-deflate/package')
v=Path('/private/tmp/roc-gap-2026-10-22/variants')
s=(root/'CompressLazy.roc').read_text()
pattern=re.compile(r'(?m)^(\t*)while \$skip_at < skip_limit \{\n')
for m in reversed(list(pattern.finditer(s))):
 i=m[1];end=s.index('\n'+i+'}',m.end());body=s[m.end():end]
 body='\n'.join(line for line in body.splitlines() if not any(x in line for x in ['skip_hashseq =','$nh3 =','$nh4 =']))+'\n'
 inner=i+'\t\t'
 new=i+'vector_limit = skip_limit.minus_saturated(1).min(List.len(input).minus_saturated(15))\n'
 new+=i+'if $skip_at < vector_limit {\n'+i+'\twhile $skip_at < vector_limit {\n'
 new+=inner+'bytes = U8x16.load(input, $skip_at) ?? crash "skip vector outside input"\n'
 new+=inner+'lanes = bytes.table_lookup(U8x16.from_list([0,1,2,16,0,1,2,3,1,2,3,16,1,2,3,4]) ?? crash "shuffle length").to_u32x4_bits()\n'
 new+=inner+'hashes = lanes.times_wrap(U32x4.splat(0x1E35A7BD)).shr_zf_wrap(16)\n'
 for lane in range(2):
  new+=inner+f'$nh3 = hashes.get_lane({lane*2}).shr_zf_wrap(1).bitwise_and(32767).to_u64()\n'
  new+=inner+f'$nh4 = hashes.get_lane({lane*2+1}).bitwise_and(65535).to_u64()\n'
  b=body
  for name in ['skip_node','prev_head']:b=re.sub(r'(?<![$\w])'+name+r'\b',name+'_'+str(lane),b)
  new+='\n'.join('\t'+line for line in b.splitlines())+'\n'
 new+=i+'\t}\n'+i+'\tfinal_seq = U32.from_le_bytes(input, $skip_at) ?? 0\n'
 new+=i+'\t$nh3 = Matchfinder.lz_hash(final_seq.bitwise_and(0xFFFFFF), HcMatchfinder.hash3_order)\n'
 new+=i+'\t$nh4 = Matchfinder.lz_hash(final_seq, HcMatchfinder.hash4_order)\n'+i+'} else {}\n'
 s=s[:m.start()]+new+s[m.start():]
(v/'CompressLazy.vector2.roc').write_text(s)
p=Path('/private/tmp/roc-gap-2026-10-22/build-batched-candidates.py')
b=p.read_text().replace("('earlyload','early-load',['CompressLazy','CompressFast'])]", "('earlyload','early-load',['CompressLazy','CompressFast']),('vector2','vector2',['CompressLazy'])]")
p.write_text(b)
