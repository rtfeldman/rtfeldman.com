from pathlib import Path
import subprocess
root=Path('/Users/rtfeldman/code/worktrees/roc-deflate/macos-deflate-gap/roc-deflate')
v=Path('/private/tmp/roc-gap-2026-10-22/variants')
s=subprocess.check_output(['git','show','34acaa2:package/CompressOptimal.roc'],cwd=root,text=True)
s=s.replace('var $nodes = List.with_capacity(CompressOptimal.optimum_nodes_size)','var $nodes = List.repeat(0.U64, CompressOptimal.optimum_nodes_size)')
a=s.index('\t\tvar $nodes = List.clear(nodes_0)');b=s.index('\n\t\t# Wrapping arithmetic on the per-node path',a)
s=s[:a]+'''\t\tif top >= List.len(nodes_0) or block_length == 0 {
\t\t\tcrash "CompressOptimal.find_min_cost_path: node list too short"
\t\t} else {}
\t\tvar $nodes = nodes_0
\t\tvar $guard = 0.U64
\t\twhile $guard < DeflateTables.max_match_len - 1 {
\t\t\t$nodes = List.set($nodes, $guard, 0x80000000) ?? crash "node guard out of range"
\t\t\t$guard = $guard.plus_wrap(1)
\t\t}
\t\t$nodes = List.set($nodes, DeflateTables.max_match_len - 1, 0) ?? crash "end node out of range"
''' + s[b:]
# This function's loop walks each position exactly once, backward.
a=s.index('\tfind_min_cost_path =');b=s.index('\n\t## The index of node 0',a)
f=s[a:b]
f=f.replace('$cur = $cur.minus_wrap(1)','$cur = $cur.minus_wrap(1)\n\t\t\tnode_at = top.minus_wrap($cur)')
f=f.replace('List.len($nodes).minus_wrap(1)','node_at.minus_wrap(1)').replace('List.len($nodes).minus_wrap(len)','node_at.minus_wrap(len)')
f=f.replace('$nodes = List.append($nodes, $best.to_u64().bitwise_or($item.to_u64().shl_wrap(32)))','$nodes = List.set($nodes, node_at, $best.to_u64().bitwise_or($item.to_u64().shl_wrap(32))) ?? crash "path node out of range"')
s=s[:a]+f+s[b:]
s=s.replace('List.last($nodes)','List.get($nodes, CompressOptimal.node_top(block_length))')
(v/'CompressOptimal.indexed.roc').write_text(s)
