import Matchfinder

## The hash-table matchfinder, ported from libdeflate's `ht_matchfinder.h`.
##
## Positions are stored biased by the window size, as the hash-chain
## matchfinder stores them (see `Matchfinder.node_bias`): the in-window test
## is one unsigned comparison against the current position, and a candidate's
## index is a wrapping add, so no entry needs sign-extending.
##
## Where the hash-chains matchfinder walks a chain, this keeps a fixed two
## entries per hash bucket and looks at both, which bounds the work per
## position without needing a depth counter. Only length-4 and longer matches
## are found, since a bucket that small cannot afford to spend an entry on
## length-3 candidates.
HtMatchfinder := [].{

	hash_order : U64
	hash_order = 15

	bucket_size : U64
	bucket_size = 2

	## Shortest match this matchfinder reports.
	min_match_len : U64
	min_match_len = 4

	## Bytes that must be readable at the search position: four for the
	## sequence itself and one more for the next position's hash.
	required_nbytes : U64
	required_nbytes = 5

	## Two entries per bucket, one bucket per hash value.
	table_size : U64
	table_size = 65536

	## The two entries of each bucket sit next to each other, so a bucket is
	## one cache line's worth of adjacent slots rather than two strided reads.
	##
	## The table is passed separately from the scalars rather than inside a
	## record: a record holding a list is copied when it crosses a call
	## boundary, which for a table this size costs far more than the search.
	State : { hash_tab : List(U16), in_cur_base : U64, next_hash : U64 }

	Match : { hash_tab : List(U16), in_cur_base : U64, next_hash : U64, length : U64, offset : U64 }

	## Find the longest match at `in_next`, considering the two candidates in
	## the position's hash bucket.
	##
	## The first entry is replaced by the current position and pushed down to
	## the second, so the bucket always holds the two most recent positions
	## with this hash. The copy happens even when the first candidate already
	## reaches `nice_len`, which costs nothing and keeps the store off the
	## branch.
	longest_match : List(U16), U64, U64, List(U8), U64, U64, U64 -> Match
	longest_match = |tab_0, base_0, hash_0, input, in_next, max_len, nice_len| {
		# The caller leaves at least the hash's bytes readable past the current
		# position. Stating that here lets the reads at and just past the
		# position skip their bounds tests.
		if in_next + max_len > List.len(input) or max_len < HtMatchfinder.required_nbytes {
			crash "HtMatchfinder.longest_match: match window outside the input"
		} else {
		}
		var $tab = tab_0
		var $base = base_0
		if in_next.minus_wrap($base) == Matchfinder.window_size {
			$tab = Matchfinder.rebase_nodes($tab)
			$base = $base.plus_wrap(Matchfinder.window_size)
		} else {
		}
		in_base = $base
		# A node at or below the current position, in the biased space the
		# tables use, is out of the window.
		cur_pos = in_next.minus_wrap(in_base)

		hash = hash_0
		next_hash = Matchfinder.lz_hash(U32.from_le_bytes(input, in_next.plus_wrap(1)) ?? 0, HtMatchfinder.hash_order)
		seq = U32.from_le_bytes(input, in_next) ?? 0

		slot0 = hash.bitwise_and(0x7FFF).times_wrap(2)
		if slot0.plus_wrap(1) >= List.len($tab) {
			crash "HtMatchfinder.longest_match: hash bucket outside the table"
		} else {
		}
		cur_node0 = List.get($tab, slot0) ?? 0
		tab1 = match List.set($tab, slot0, cur_pos.plus_wrap(Matchfinder.node_bias).to_u16_wrap()) {
			Ok(next) => next
			Err(_) => crash "HtMatchfinder.longest_match: tab index out of bounds"
		}

		var $best_len = 0.U64
		var $best_match_at = in_next

		if cur_node0.to_u64() <= cur_pos {
			{ hash_tab: tab1, in_cur_base: in_base, next_hash, length: 0, offset: 0 }
		} else {
			match0_at = Matchfinder.node_before(in_next, cur_pos, cur_node0)

			# Push the displaced entry into the second slot.
			cur_node1 = List.get(tab1, slot0.plus_wrap(1)) ?? 0
			var $tab2 = match List.set(tab1, slot0.plus_wrap(1), cur_node0) {
				Ok(next) => next
				Err(_) => crash "HtMatchfinder.longest_match: tab1 index out of bounds"
			}

			if (U32.from_le_bytes(input, match0_at) ?? 0) == seq {
				$best_len = Matchfinder.lz_extend(input, in_next, match0_at, 4, max_len)
				$best_match_at = match0_at
				if cur_node1.to_u64() <= cur_pos or $best_len >= nice_len {
				} else {
					match1_at = Matchfinder.node_before(in_next, cur_pos, cur_node1)
					if (U32.from_le_bytes(input, match1_at) ?? 0) == seq
						and (U32.from_le_bytes(input, match1_at.plus_wrap($best_len).minus_wrap(3)) ?? 0)
							== (U32.from_le_bytes(input, in_next.plus_wrap($best_len).minus_wrap(3)) ?? 0) {
						len = Matchfinder.lz_extend(input, in_next, match1_at, 4, max_len)
						if len > $best_len {
							$best_len = len
							$best_match_at = match1_at
						} else {
						}
					} else {
					}
				}
			} else {
				if cur_node1.to_u64() <= cur_pos {
				} else {
					match1_at = Matchfinder.node_before(in_next, cur_pos, cur_node1)
					if (U32.from_le_bytes(input, match1_at) ?? 0) == seq {
						$best_len = Matchfinder.lz_extend(input, in_next, match1_at, 4, max_len)
						$best_match_at = match1_at
					} else {
					}
				}
			}

			{
				hash_tab: $tab2,
				in_cur_base: in_base,
				next_hash,
				length: $best_len,
				offset: in_next.minus_wrap($best_match_at),
			}
		}
	}

	## Insert `count` positions into the buckets without searching them.
	skip_bytes : List(U16), U64, U64, List(U8), U64, U64, U64 -> State
	skip_bytes = |tab_0, base_0, hash_0, input, in_next0, in_end, count| {
		# The run ends at `end`, and every hash read the loop makes lies within
		# `required_nbytes` of it. These two sums are checked rather than
		# wrapping so that the bound they establish is a fact the range prover
		# can carry into the loop: with it, and the bucket table's size once
		# after any slide, every read and bucket access in the loop is proven
		# in bounds, so each byte pays only for the work itself.
		end = in_next0 + count
		if end + HtMatchfinder.required_nbytes > in_end {
			{ hash_tab: tab_0, in_cur_base: base_0, next_hash: hash_0 }
		} else if in_end > List.len(input) {
			crash "HtMatchfinder.skip_bytes: input end past the input"
		} else {
			var $tab = tab_0
			var $base = base_0
			var $in_next = in_next0
			var $cur_pos = $in_next.minus_wrap(base_0).to_i64_wrap()
			# One slide covers the whole run, since it is bounded by a window.
			if $cur_pos.plus_wrap(count.to_i64_wrap()).minus_wrap(1) >= Matchfinder.window_size.to_i64_wrap() {
				$tab = Matchfinder.rebase_nodes($tab)
				$base = $base.plus_wrap(Matchfinder.window_size)
				$cur_pos = $cur_pos.minus_wrap(Matchfinder.window_size.to_i64_wrap())
			} else {
			}
			if List.len($tab) < HtMatchfinder.table_size {
				crash "HtMatchfinder.skip_bytes: hash table too short"
			} else {
			}

			# Wrapping arithmetic: the run was bounded against the input above and
			# a bucket index is a masked hash doubled, so nothing here can overflow
			# and a checked add would only cost a branch per byte.
			var $hash = hash_0
			# The node written for each position is the biased position, so the
			# loop carries it directly rather than biasing on every store.
			var $node = $cur_pos.plus_wrap(Matchfinder.node_bias.to_i64_wrap())
			while $in_next < end {
				slot0 = $hash.bitwise_and(0x7FFF).times_wrap(2)
				first = List.get($tab, slot0) ?? 0
				tab1 = match List.set($tab, slot0.plus_wrap(1), first) {
					Ok(next) => next
					Err(_) => crash "HtMatchfinder.skip_bytes: tab index out of bounds"
				}
				$tab = match List.set(tab1, slot0, $node.to_u16_wrap()) {
					Ok(next) => next
					Err(_) => crash "HtMatchfinder.skip_bytes: tab1 index out of bounds"
				}

				$in_next = $in_next.plus_wrap(1)
				$hash = Matchfinder.lz_hash(U32.from_le_bytes(input, $in_next) ?? 0, HtMatchfinder.hash_order)
				$node = $node.plus_wrap(1)
			}
			{ hash_tab: $tab, in_cur_base: $base, next_hash: $hash }
		}
	}
}
